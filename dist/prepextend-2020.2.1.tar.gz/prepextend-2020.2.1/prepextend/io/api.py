# -*- coding: utf-8 -*-
"""
Created on Wed Nov 18 22:04:35 2020

@author: weihao
"""

from prep_extension.io.prep_read_main import ( 
        prep_read
        )

